package cl.ucn.Taller2BrayanCecilia.logica;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

public class App {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		Sistema sis=new SistemaImpl();
		Scanner sc=new Scanner(System.in);

		leerArmas(sis);

		leerPiezas(sis);

		leerRobot(sis);

		Menu(sis,sc);
		
	}
	public static void Menu(Sistema sis,Scanner sc) throws IOException {
		
		
		
		System.out.print("INGRESE LA OPCION QUE DESEA REALIZAR O -1 PARA CERRAR EL SISTEMA\n");
		System.out.print("(1) INICIAR SIMULACION\n");
		System.out.print("(2) A�ADIR PIEZA\n");
		System.out.print("(3) ENSAMBLAR ROBOT\n");
		System.out.print("(4) CAMBIAR PIEZAS DE UN ROBOT\n");
		System.out.print("(5) CAMBIAR ARMA DE UN ROBOT\n");
		System.out.print("(6) MOSTRAR ESTADISTICAS DE ROBOTS\n");
		System.out.print("(7) MOSTRAR ROBOT QUE SON MANEJADOS POR UN PILOTO\n");
		System.out.print("(8) MOSTRAR ROBOTS DE UN EQUIPO\n");
		System.out.print("(9) MOSTRAR ESTADISTICAS DE VICTORIAS HUMANIDAD\n");
		

		System.out.println("Ingrese su opcion: ");
		
		int op = Integer.parseInt(sc.nextLine());
		
		while(op!=-1) {
			switch (op) {
			case 1: {
				sis.ingresarCombate();
			}
			case 2: {
				sis.ingresarNuevaPieza();
			}
			case 3: {
				sis.ingresarNuevaRobot();
			}
			case 4: {
				sis.cambiarPieza();
			}
			case 5: {
				sis.cambiarArma();
			}
			case 6: {
				sis.obtenerEstadisticas();
			}
			case 7: {
				sis.obtenerRobotsPilotos();
			}
			case 8: {
				sis.obtenerRobotEquipo();
			}
			case 9: {
				sis.obtenerEstadiscticasVictoriaHumanidad();
			}
			
			}
			System.out.println("INGRESE UNA OPCION NUEVAMENTE\n" );
			System.out.print("(1) INICIAR SIMULACION\n");
			System.out.print("(2) A�ADIR PIEZA\n");
			System.out.print("(3) ENSAMBLAR ROBOT\n");
			System.out.print("(4) CAMBIAR PIEZAS DE UN ROBOT\n");
			System.out.print("(5) CAMBIAR ARMA DE UN ROBOT\n");
			System.out.print("(6) MOSTRAR ESTADISTICAS DE ROBOTS\n");
			System.out.print("(7) MOSTRAR ROBOT QUE SON MANEJADOS POR UN PILOTO\n");
			System.out.print("(8) MOSTRAR ROBOTS DE UN EQUIPO\n");
			System.out.print("(9) MOSTRAR ESTADISTICAS DE VICTORIAS HUMANIDAD");
			op=Integer.parseInt(sc.nextLine());
		}
		
		sc.close();
		sis.cerrar();
		
	}
	public static void leerArmas(Sistema sis) throws FileNotFoundException {
		Scanner read=new Scanner(new File("armas.txt"));
		while(read.hasNextLine()) {
			String[]partes=read.nextLine().split(",");
			String nombre=partes[0];
			int dano=Integer.parseInt(partes[1]);
			int velocidad=Integer.parseInt(partes[2]);
			
			sis.ingresarArma(nombre, dano, velocidad);
		}


	}
	public static void leerPiezas(Sistema sis) throws FileNotFoundException {
		Scanner read=new Scanner(new File("piezas.txt"));
		
		while(read.hasNextLine()) {
			String[]partes=read.nextLine().split(",");
			
			String nombre=partes[0];
			String rareza=partes[1];
			String tipo=partes[2];
			if(tipo.equalsIgnoreCase("P")) {
				int velocidad=Integer.parseInt(partes[3]);
				sis.ingresarPieza(nombre, rareza, tipo, 0, 0, velocidad);
			}else if(tipo.equalsIgnoreCase("B")) {
				int ataque=Integer.parseInt(partes[3]);
				sis.ingresarPieza(nombre, rareza, tipo,0,ataque,0);
			}else if(tipo.equalsIgnoreCase("T")) {
				int vida=Integer.parseInt(partes[3]);
				sis.ingresarPieza(nombre, rareza, tipo, vida, 0, 0);
			}else if(tipo.equalsIgnoreCase("C")) {
				int velociada=Integer.parseInt(partes[3]);
				int vida=Integer.parseInt(partes[4]);
				sis.ingresarPieza(nombre, rareza, tipo, vida, 0, velociada);
				
			}
		}
		
	
	}
	
	public static void leerRobot(Sistema sis) throws FileNotFoundException {
		Scanner read=new Scanner(new File("Robots.txt"));
		
		while(read.hasNextLine()) {
			String linea = read.nextLine();
			String[]partes=linea.split(",");
			
			String tipo=partes[6];
			
			if(tipo.equalsIgnoreCase("H")) {
				String nombre=partes[0];
				String arma=partes[1];
				String pierna=partes[2];
				String brazoz=partes[3];
				String torax=partes[4];
				String cabeza=partes[5];
				String nomPiloto=partes[7];
				String equipo=partes[8];
				sis.ingresarRobotH(nombre, nomPiloto, equipo);				
				sis.asociarPiezasRobot(nombre, pierna, brazoz, torax, cabeza);
				sis.asociarArmaRobot(nombre,arma);
				sis.calcular();

			}else if(tipo.equalsIgnoreCase("A")) {
				String nombre=partes[0];
				String arma=partes[1];
				String pierna=partes[2];
				String brazoz=partes[3];
				String torax=partes[4];
				String cabeza=partes[5];
				String clase=partes[7];
				int escudo=Integer.parseInt(partes[8]);
				sis.ingresarRobotA(nombre, clase, escudo);
				sis.asociarPiezasRobot(nombre, pierna, brazoz, torax, cabeza);
				sis.asociarArmaRobot(nombre, arma);
				sis.calcular();

			}
		}

	}

}
