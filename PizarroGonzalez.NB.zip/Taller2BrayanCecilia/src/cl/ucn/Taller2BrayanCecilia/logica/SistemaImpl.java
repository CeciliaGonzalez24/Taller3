package cl.ucn.Taller2BrayanCecilia.logica;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

import cl.ucn.Taller2BrayanCecilia.dominio.*;

public class SistemaImpl implements Sistema {
	ArrayList<Robots> listaRobots = new ArrayList<Robots>();
	ArrayList<Arma> listaArma = new ArrayList<>();
	ArrayList<Pieza> listaPiezas = new ArrayList<>();
	ArrayList<Combates> listaCombates = new ArrayList<>();

	@Override
	/**
	 * This function create and add to listaArma a new Arma.
	 * 
	 */
	public void ingresarArma(String nombre, int dano, int velAtq) {
		Arma a = new Arma(nombre, dano, velAtq);
		listaArma.add(a);
		// TODO Auto-generated method stub

	}

	@Override
	/**
	 * This function create and add to listaPiezas a new Pieza.
	 */
	public void ingresarPieza(String nombre, String rareza, String tipo, int vida, int ataque, int velocidad) {
		// TODO Auto-generated method stub
		if (tipo.equalsIgnoreCase("P")) {
			Piernas p = new Piernas(nombre, rareza, tipo, velocidad);
			listaPiezas.add(p);
		} else if (tipo.equalsIgnoreCase("B")) {
			Brazos b = new Brazos(nombre, rareza, tipo, ataque);
			listaPiezas.add(b);
		} else if (tipo.equalsIgnoreCase("T")) {
			Torax t = new Torax(nombre, rareza, tipo, vida);
			listaPiezas.add(t);
		} else if (tipo.equalsIgnoreCase("C")) {
			Cabeza c = new Cabeza(nombre, rareza, tipo, vida, velocidad);
			listaPiezas.add(c);
		}
	}

	@Override
	/**
	 * 
	 */
	public void ingresarRobotH(String nombre, String nomPiloto, String equipoMan) {
		RobotH h = new RobotH(nombre, nomPiloto, equipoMan);
		listaRobots.add(h);
		// TODO Auto-generated method stub

	}

	@Override
	public void ingresarRobotA(String nombre, String clase, int escudo) {
		RobotA a = new RobotA(nombre, clase, escudo);
		listaRobots.add(a);
		// TODO Auto-generated method stub

	}

	@Override
	public void asociarPiezasRobot(String nombreRobot, String piernas, String brazos, String torax, String cabeza) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		Robots r = buscarRobot(nombreRobot);
		Piernas p = (Piernas) buscarPieza(piernas);
		Brazos b = (Brazos) buscarPieza(brazos);
		Torax t = (Torax) buscarPieza(torax);
		Cabeza c = (Cabeza) buscarPieza(cabeza);

		while (r == null) {
			System.out.println("EL NOMBRE DEL ROBOT ES INCORRECTO INGRES UN NOMBRE VALIDO:");
			nombreRobot = scan.nextLine();
			r = buscarRobot(nombreRobot);
		}

		while (p == null) {
			System.out.println("EL NOMBRE DE LAS PIERNAS ES INCORRECTO INGRES UN NOMBRE VALIDO:");
			piernas = scan.nextLine();
			p = (Piernas) buscarPieza(piernas);
		}
		r.setPiernas(p);
		while (b == null) {
			System.out.println("EL NOMBRE DE LOS BRAZOS ES INCORRECTO INGRES UN NOMBRE VALIDO:");
			brazos = scan.nextLine();
			b = (Brazos) buscarPieza(brazos);
		}
		r.setBrazos(b);
		while (t == null) {
			System.out.println("EL NOMBRE DE EL TORAX ES INCORRECTO INGRES UN NOMBRE VALIDO:");
			torax = scan.nextLine();
			t = (Torax) buscarPieza(torax);
		}
		r.setTorax(t);
		while (c == null) {
			System.out.println("EL NOMBRE DE LA CABEZA ES INCORRECTO INGRES UN NOMBRE VALIDO:");
			cabeza = scan.nextLine();
			c = (Cabeza) buscarPieza(cabeza);
		}
		r.setCabeza(c);

		/*
		 * if(r instanceof RobotA) { r.setVida(0); r.setAtaque(0); r.setVelocidad(0);
		 * 
		 * }else if(r instanceof RobotH) { r.setVida(0); r.setAtaque(0);
		 * r.setVelocidad(0);
		 * 
		 * }
		 */

	}

	@Override
	public void asociarArmaRobot(String nombreRobot, String arma) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		Robots r = buscarRobot(nombreRobot);
		Arma a = buscarArma(arma);
		while (r == null) {
			System.out.println("EL NOMBRE DEL ROBOT ES INCORRECTO INGRESE UN NOMBRE VALIDO");
			nombreRobot = scan.nextLine();
			r = buscarRobot(nombreRobot);
		}
		while (a == null) {
			System.out.println("EL NOMBRE DEL ROBOT ES INCORRECTO INGRESE UN NOMBRE VALIDO");
			arma = scan.nextLine();
			a = buscarArma(arma);
		}
		r.setArma(a);
		if (r instanceof RobotH) {
			RobotH h = (RobotH) r;
			h.calcular();
		} else if (r instanceof RobotA) {
			RobotA e = (RobotA) r;
			e.calcular();
		}

	}

	private Arma buscarArma(String nombre) {
		for (Arma a : listaArma) {
			if (a.getNombre().equals(nombre)) {
				return a;
			}
		}
		return null;
	}

	private Robots buscarRobot(String nombre) {
		for (Robots r : listaRobots) {
			if (r.getNombre().equals(nombre)) {
				return r;
			}
		}
		return null;
	}

	private Pieza buscarPieza(String nombre) {
		for (Pieza p : listaPiezas) {
			if (p.getNombre().equals(nombre)) {
				return p;
			}
		}
		return null;
	}

	@Override
	public void obtenerRobotH() {
		// TODO Auto-generated method stub

	}

	@Override
	public void calcular() {
		// TODO Auto-generated method stub
		for (Robots r : listaRobots) {
			if (r instanceof RobotH) {
				RobotH h = (RobotH) r;
				h.calcular();
			} else if (r instanceof RobotA) {
				RobotA a = (RobotA) r;
				a.calcular();
			}
		}
	}

	@Override
	public void ingresarCombate() {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		Combates c = new Combates();
		System.out.println("INGRESE EL NOMBRE DE LOS ROBOT HUMANOS");
		Robots r1 = buscarRobot(scan.nextLine());
		int contador = 0;
		while (contador < 3) {
			if (r1 != null) {
				c.getLr().add(r1);
				contador++;
				System.out.println("INGRESA EL SIGUIENTE ROBOT:");
				r1 = buscarRobot(scan.nextLine());
			} else {
				System.out.println("EL NOMBRE DEL ROBOT INGRESADO ES INCORRECTO INTENTELO NUEVAMENTE");
				r1 = buscarRobot(scan.nextLine());

			}

		}
		System.out.println("INGRESE EL NOMBRE DE LOS ROBOT EXTRATERRESTRES");
		Robots r2 = buscarRobot(scan.nextLine());
		while (contador < 6) {
			if (r2 != null) {
				c.getLr().add(r2);
				contador++;
				System.out.println("INGRESA EL SIGUIENTE ROBOT:");
				r2 = buscarRobot(scan.nextLine());
			} else {
				System.out.println("EL NOMBRE DEL ROBOT INGRESADO ES INCORRECTO INTENTELO NUEVAMENTE");
				r2 = buscarRobot(scan.nextLine());

			}

		}
		combate(c);
		listaCombates.add(c);

	}

	private void combate(Combates c) {
		int victoriasH = 0;
		int victoriasA = 0;
		Robots h1 = c.getLr().get(0);
		Robots h2 = c.getLr().get(1);
		Robots h3 = c.getLr().get(2);

		Robots a1 = c.getLr().get(3);
		Robots a2 = c.getLr().get(4);
		Robots a3 = c.getLr().get(5);

		Robots ganador1 = vs(h1, a1);

		if (ganador1 instanceof RobotA) {
			// win first combat is robot alien 1;
			victoriasA++;
			Robots ganador2 = vs(ganador1, h2);
			if (ganador2 instanceof RobotA) {
				// win second combat is robot alien 1;
				victoriasA++;
				Robots ganador3 = vs(ganador2, h3);
				if (ganador3 instanceof RobotA) {
					// win third combat is robot alien 1, end the combat;
					victoriasA++;
				} else if (ganador3 instanceof RobotH) {
					// win third combat is robot human 3
					victoriasH++;
					Robots ganador4 = vs(ganador2, a2);
					if (ganador4 instanceof RobotA) {
						// win fourth combat is robot alien 2,end the combat ;
						victoriasA++;
					} else if (ganador4 instanceof RobotH) {
						// win fourth second combat is robot human 3;
						victoriasH++;
						Robots ganador5 = vs(ganador2, a3);
						if (ganador5 instanceof RobotA) {
							// win fifth combat is robot alien 3,end the combat;
							victoriasA++;

						} else if (ganador5 instanceof RobotH) {
							// win fifth combat is robot human 3,end the combat;
							victoriasH++;
						}
					}
				}

			} else if (ganador2 instanceof RobotH) {
				// win second combat is robot human 2;
				victoriasH++;
				Robots ganador3 = vs(ganador2, a2);
				if (ganador3 instanceof RobotA) {
					// win third combat is robot alien 2, end the combat;
					victoriasA++;
					Robots ganador4 = vs(ganador3, h3);
					if (ganador4 instanceof RobotA) {
						// win second combat is robot alien 2, end the combat;
						victoriasA++;

					} else if (ganador4 instanceof RobotH) {
						// win second combat is robot human 3;
						victoriasH++;
						Robots ganador5 = vs(ganador2, a3);
						if (ganador5 instanceof RobotA) {
							// win second combat is robot alien 3,end the combat;
							victoriasA++;

						} else if (ganador5 instanceof RobotH) {
							// win second combat is robot human 3,end the combat;
							victoriasH++;

						}
					}

				} else if (ganador3 instanceof RobotH) {
					// win third combat is robot human 2
					victoriasH++;
					Robots ganador4 = vs(ganador2, a3);
					if (ganador4 instanceof RobotA) {
						// win fourth combat is robot alien 3,end the combat ;
						victoriasA++;
						Robots ganador5 = vs(ganador4, h3);
						if (ganador5 instanceof RobotA) {
							// win second combat is robot alien 3,end the combat;
							victoriasA++;

						} else if (ganador5 instanceof RobotH) {
							// win second combat is robot human 3,end the combat;
							victoriasH++;

						}

					} else if (ganador4 instanceof RobotH) {
						// win fourth second combat is robot human 2,end the combat;
						victoriasH++;

					}
				}
			}
		} else if (ganador1 instanceof RobotH) {
			// win first combat is robot human 1;
			victoriasH++;
			Robots ganador2 = vs(ganador1, a2);
			if (ganador2 instanceof RobotA) {
				// win second combat is robot alien 2;
				victoriasA++;
				Robots ganador3 = vs(ganador2, h2);
				if (ganador3 instanceof RobotA) {
					// win second combat is robot alien 2;
					victoriasA++;
					Robots ganador4 = vs(ganador2, h3);

					if (ganador4 instanceof RobotA) {
						// win second combat is robot alien 2,end the combat;
						victoriasA++;

					} else if (ganador4 instanceof RobotH) {
						// win second combat is robot human 3;
						victoriasH++;
						Robots ganador5 = vs(ganador2, a3);
						if (ganador5 instanceof RobotA) {
							// win second combat is robot alien 3,end the combat;
							victoriasA++;

						} else if (ganador5 instanceof RobotH) {
							// win second combat is robot human 3,end the combat;
							victoriasH++;

						}
					}
				} else if (ganador3 instanceof RobotH) {
					// win second combat is robot human 2;
					victoriasH++;
					Robots ganador4 = vs(ganador2, a3);
					if (ganador4 instanceof RobotA) {
						// win second combat is robot alien 3;
						victoriasA++;
						Robots ganador5 = vs(ganador2, h3);
						if (ganador5 instanceof RobotA) {
							// win second combat is robot alien 3,end the combat;
							victoriasA++;

						} else if (ganador5 instanceof RobotH) {
							// win second combat is robot human 3,end the combat;
							victoriasH++;

						}

					} else if (ganador4 instanceof RobotH) {
						// win second combat is robot human 2,end the combat;
						victoriasH++;

					}
				}
			} else if (ganador2 instanceof RobotH) {
				// win second combat is robot human 1;
				victoriasH++;
				Robots ganador3 = vs(ganador2, a3);
				if (ganador3 instanceof RobotA) {
					// win second combat is robot alien 3;
					victoriasA++;
					Robots ganador4 = vs(ganador3, h2);
					if (ganador4 instanceof RobotA) {
						// win second combat is robot alien 3,end the combat;
						victoriasA++;

					} else if (ganador4 instanceof RobotH) {
						// win second combat is robot human 2,end the combat;
						victoriasH++;

					}

				} else if (ganador3 instanceof RobotH) {
					// win second combat is robot human 1,end the combat;
					victoriasH++;

				}
			}
		}
		if (victoriasA > victoriasH) {
			System.out.println("GANADORES EXTRATERRESTRES ");
			c.setGanador("EXTRATERRESTRES");
		} else {
			System.out.println("GANADORES HUMANOS");
			c.setGanador("HUMANOS");
		}

	}

	private Robots vs(Robots h1, Robots a1) {

		if (h1.getVelocidad() > a1.getVelocidad()) {
			while (h1.getVida() > 0 && a1.getVida() > 0) {
				a1.setVida(a1.getVida() - h1.getAtaque());
				h1.setVida(h1.getVida() - a1.getAtaque());
			}
		} else if (h1.getVelocidad() < a1.getVelocidad()) {
			while (a1.getVida() > 0 && h1.getVida() > 0) {
				h1.setVida(h1.getVida() - a1.getAtaque());
				a1.setVida(a1.getVida() - h1.getAtaque());
			}
		}
		if (h1.getVida() > 0) {
			return h1;
		} else if (a1.getVida() > 0) {
			return a1;
		}
		return null;
	}

	@Override
	public void cambiarPieza() {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		System.out.println("INGRESE EL NOMBRE DEL ROBOT QUE DESEA CAMBIARLE UNA PIEZA");
		String nombre = scan.nextLine();
		while (buscarRobot(nombre) == null) {
			System.out.println("EL NOMBRE DEL ROBOT QUE BUSCA NO EXISTE, INGRESE UNO NUEVAMENTE");
			nombre = scan.nextLine();
		}
		Robots r = buscarRobot(nombre);
		System.out.println("INGRESE LA CLAVE DE LA PIEZA QUE DESEA CAMBIAR (P,B,T,C)");
		String tipo = scan.nextLine();
		switch (tipo) {
		case "p": {
			System.out.println("INGRESE EL NOMBRE DE LAS PIERNAS");
			String nombrePiernas = scan.nextLine();
			while (buscarPieza(nombrePiernas) == null) {
				System.out.println("EL NOMBRE DE LAS PIERNAS ES INCORECTO INGRESELO NUEVAMENTE");
				nombrePiernas = scan.nextLine();
			}
			r.setPiernas((Piernas) buscarPieza(nombrePiernas));
		}
		case "B": {
			System.out.println("INGRESE EL NOMBRE DE BRAZOS");
			String nombreBrazos = scan.nextLine();
			while (buscarPieza(nombreBrazos) == null) {
				System.out.println("EL NOMBRE DE LAS PIERNAS ES INCORECTO INGRESELO NUEVAMENTE");
				nombreBrazos = scan.nextLine();
			}
			r.setBrazos((Brazos) buscarPieza(nombreBrazos));
			;
		}
		case "T": {
			System.out.println("INGRESE EL NOMBRE DEL TORAX");
			String nombreTorax = scan.nextLine();
			while (buscarPieza(nombreTorax) == null) {
				System.out.println("EL NOMBRE DE LAS PIERNAS ES INCORECTO INGRESELO NUEVAMENTE");
				nombreTorax = scan.nextLine();
			}
			r.setTorax((Torax) buscarPieza(nombreTorax));
		}
		case "C": {
			System.out.println("INGRESE EL NOMBRE DE LA CABEZA");
			String nombreCabeza = scan.nextLine();
			while (buscarPieza(nombreCabeza) == null) {
				System.out.println("EL NOMBRE DE LAS PIERNAS ES INCORECTO INGRESELO NUEVAMENTE");
				nombreCabeza = scan.nextLine();
			}
			r.setCabeza((Cabeza) buscarPieza(nombreCabeza));
		}
		}

	}

	@Override
	public void cambiarArma() {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		System.out.println("INGRESE EL NOMBRE DEL ROBOT QUE DESEA CAMBIARLE UNA PIEZA");
		String nombre = scan.nextLine();
		Robots r = buscarRobot(nombre);

		System.out.println("INGRESE EL NOMBRE DEL ARMA QUE DESEA CAMBIAR");
		String arma = scan.nextLine();
		while (buscarArma(arma) == null) {
			System.out.println("EL NOMBRE DE LAS PIERNAS ES INCORECTO INGRESELO NUEVAMENTE");
			arma = scan.nextLine();
		}
		r.setArma(buscarArma(arma));

	}

	@Override
	public void obtenerEstadisticas() {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		System.out.println("INGRESE EL NOMBRE DEL ROBOT QUE DESEA VER LAS ESTADISTICAS");
		String nombre = scan.nextLine();
		while (buscarRobot(nombre) == null) {
			System.out.println("EL NOMBRE DEL ROBOT QUE BUSCA NO EXISTE, INGRESE UNO NUEVAMENTE");
			nombre = scan.nextLine();
		}
		Robots r = buscarRobot(nombre);
		if (r instanceof RobotA) {
			System.out.println("NOMBRE:" + r.getNombre() + " VIDA:" + r.getVida() + " VELOCIDAD" + r.getVelocidad()
					+ " ATAQUE:" + r.getAtaque() + " ESCUDO" + ((RobotA) r).getEscudo());
		} else if (r instanceof RobotH) {
			System.out.println("NOMBRE:" + r.getNombre() + " VIDA:" + r.getVida() + " VELOCIDAD" + r.getVelocidad()
					+ " ATAQUE:" + r.getAtaque());
		}

	}

	@Override
	public void obtenerRobotsPilotos() {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		System.out.println("INGRESE EL NOMBRE DEL PILOTO QUE DESEA BUSCAR:");
		String nombrePiloto = scan.nextLine();

		for (Robots r : listaRobots) {
			if (r instanceof RobotH) {
				RobotH h = (RobotH) r;
				if (h.getNomPiloto().equalsIgnoreCase(nombrePiloto)) {
					System.out.println(h.toString());
				}
			}
		}

	}

	@Override
	public void ingresarNuevaRobot() {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		System.out.println("DESEA ENSAMBLAR UN ROBOT EXTRATERRESTRE(A),HUMANO(H)");
		String tipo = scan.nextLine();
		switch (tipo) {
		case "A": {
			System.out.println("INGRESE EL NOMBRE ROBOT:");
			String nombre = scan.nextLine();
			System.out.println("INGRESE LA CLASE");
			String clase = scan.nextLine();
			System.out.println("INGRESE EL ESCUDO");
			int escudo = Integer.parseInt(scan.nextLine());
			System.out.println("INGRESE PIERNAS ");
			String pierna = scan.nextLine();
			System.out.println("INGRESE BRAZO");
			String brazo = scan.nextLine();
			System.out.println("INGRESE TORAX");
			String torax = scan.nextLine();
			System.out.println("INGRESE CABEZA");
			String cabeza = scan.nextLine();
			System.out.println("INGRESE ARMA");
			String arma = scan.nextLine();
			ingresarRobotA(nombre, clase, escudo);
			asociarPiezasRobot(nombre, pierna, brazo, torax, cabeza);
			asociarArmaRobot(nombre, arma);
		}
		case "H": {
			System.out.println("INGRESE EL NOMBRE ROBOT:");
			String nombre = scan.nextLine();
			System.out.println("INGRESE PILOTO");
			String piloto = scan.nextLine();
			System.out.println("INGRESE EL EQUIPO");
			String equipo = scan.nextLine();
			System.out.println("INGRESE PIERNAS ");
			String pierna = scan.nextLine();
			System.out.println("INGRESE BRAZO");
			String brazo = scan.nextLine();
			System.out.println("INGRESE TORAX");
			String torax = scan.nextLine();
			System.out.println("INGRESE CABEZA");
			String cabeza = scan.nextLine();
			System.out.println("INGRESE ARMA");
			String arma = scan.nextLine();
			ingresarRobotH(nombre, piloto, equipo);
			asociarPiezasRobot(nombre, pierna, brazo, torax, cabeza);
			asociarArmaRobot(nombre, arma);
		}
		}

	}

	@Override
	public void ingresarNuevaPieza() {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);

		System.out.println("INGRESE EL NOMBRE DE LA PIEZA NUEVA");
		String nombre = scan.nextLine();
		System.out.println("INGRESE LA RAREZA DE LA PIEZA(PP,PE,PC)");
		String rareza = scan.nextLine();
		System.out.println("INGRESE EL TIPO DE PIEZA(P,B,T,C)");
		String tipo = scan.nextLine();

		switch (tipo) {
		case "p": {
			System.out.println("INGRESE LA VELOCIDAD");
			int velocidad = Integer.parseInt(scan.nextLine());
			ingresarPieza(nombre, rareza, tipo, 0, 0, velocidad);
		}
		case "B": {
			System.out.println("INGRESE EL ATAQUE");
			int ataque = Integer.parseInt(scan.nextLine());
			ingresarPieza(nombre, rareza, tipo, 0, ataque, 0);
		}
		case "T": {
			System.out.println("INGRESE LA VIDA");
			int vida = Integer.parseInt(scan.nextLine());
			ingresarPieza(nombre, rareza, tipo, vida, 0, 0);
		}
		case "C": {
			System.out.println("INGRESE LA VELOCIDAD");
			int velocidad = Integer.parseInt(scan.nextLine());
			System.out.println("INGRESE LA VIDA");
			int vida = Integer.parseInt(scan.nextLine());
			ingresarPieza(nombre, rareza, tipo, vida, 0, velocidad);
		}
		}

	}

	@Override
	public void obtenerRobotEquipo() {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		System.out.println("INGRESE EL NOMBRE DEL EQUIPO QUE DESEA BUSCAR:");
		String nombreEquipo = scan.nextLine();

		for (Robots r : listaRobots) {
			if (r instanceof RobotH) {
				RobotH h = (RobotH) r;
				if (h.getEquipoMan().equalsIgnoreCase(nombreEquipo)) {
					System.out.println(h.toString());
				}
			}
		}

	}

	@Override
	public void obtenerEstadiscticasVictoriaHumanidad() {
		// TODO Auto-generated method stub
		int victorias = 0;
		if (!listaCombates.isEmpty()) {
			for (Combates c : listaCombates) {
				if (c.getGanador().equalsIgnoreCase("HUMANOS")) {
					victorias++;

				}
			}
		}
		System.out.println("LOS HUMANOS GANARON UN TOTAL DE: " + victorias);

	}

	@Override
	public void cerrar() throws IOException {
		// TODO Auto-generated method stub
		File archivo = new File("Combates.txt");
		FileWriter escribir = new FileWriter(archivo, true);

		for (Combates c : listaCombates) {

			escribir.write(c.getLr().get(0).getNombre() + "," + c.getLr().get(1).getNombre() + ","
					+ c.getLr().get(2).getNombre() + "," + c.getLr().get(3).getNombre() + ","
					+ c.getLr().get(4).getNombre() + "," + c.getLr().get(5).getNombre() + "," + c.getGanador());
			escribir.write("\r\n");

		}
		escribir.close();

		File archivo1 = new File("Robots.txt");
		FileWriter escribir1 = new FileWriter(archivo1);

		for (Robots r : listaRobots) {
			if (r instanceof RobotH) {
				RobotH h = (RobotH) r;
				escribir1.write(r.getNombre() + "," + r.getArma().getNombre() + "," + r.getPiernas().getNombre() + ","
						+ r.getBrazos().getNombre() + "," + r.getTorax().getNombre() + "," + r.getCabeza() + ",H,"
						+ h.getNomPiloto() + "," + h.getEquipoMan());
				escribir1.write("\r\n");
			} else if (r instanceof RobotA) {
				RobotA a = (RobotA) r;
				escribir1.write(r.getNombre() + "," + r.getArma().getNombre() + "," + r.getPiernas().getNombre() + ","
						+ r.getBrazos().getNombre() + "," + r.getTorax().getNombre() + "," + r.getCabeza() + ",A,"
						+ a.getEscudo() + "," + a.getClase());
				escribir1.write("\r\n");
			}
		}
		escribir1.close();

		File archivo2 = new File("piezas.txt");
		FileWriter escribir2 = new FileWriter(archivo2);

		for (Pieza p : listaPiezas) {
			if (p instanceof Piernas) {
				Piernas pi = (Piernas) p;
				escribir2.write(p.getNombre() + "," + p.getRareza() + "," + p.getTipo() + "," + pi.getVelocidad());
				escribir2.write("\r\n");
			} else if (p instanceof Brazos) {
				Brazos b = (Brazos) p;
				escribir2.write(p.getNombre() + "," + p.getRareza() + "," + p.getTipo() + "," + b.getAtaque());
				escribir2.write("\r\n");
			} else if (p instanceof Torax) {
				Torax t = (Torax) p;
				escribir2.write(
						p.getNombre() + "," + p.getRareza() + "," + p.getTipo() + "," + (t.getVidabase() - 2000));
				escribir2.write("\r\n");
			} else if (p instanceof Cabeza) {
				Cabeza c = (Cabeza) p;
				escribir2.write(p.getNombre() + "," + p.getRareza() + "," + p.getTipo() + "," + c.getVelocidad() + ","
						+ (c.getVidabase() - 2000));
				escribir2.write("\r\n");
			}
		}
		escribir2.close();

		File archivo3 = new File("armas.txt");
		FileWriter escribir3 = new FileWriter(archivo3);

		for (Arma a : listaArma) {
			escribir.write(a.getNombre() + "," + a.getDano() + "," + a.getVelAtq());
			escribir3.write("\r\n");
		}
		escribir3.close();
	}

}
