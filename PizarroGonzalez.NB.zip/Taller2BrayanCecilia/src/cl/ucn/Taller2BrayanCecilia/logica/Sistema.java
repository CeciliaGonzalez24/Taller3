package cl.ucn.Taller2BrayanCecilia.logica;

import java.io.IOException;
public interface Sistema {
void ingresarArma(String nombre,int dano,int velAtq);
void ingresarPieza(String nombre,String rareza,String tipo,int vida,int ataque,int velocidad);
void ingresarRobotH(String nombre,String nomPiloto,String equipoMan);	
void ingresarRobotA(String nombre,String clase,int escudo);
void asociarPiezasRobot(String nombreRobot,String piernas,String brazos,String torax,String cabeza);
void asociarArmaRobot(String nombreRobot,String arma);
void obtenerRobotH();
void calcular();
void ingresarCombate();
void cambiarPieza();
void cambiarArma();
void obtenerEstadisticas();
void obtenerRobotsPilotos();
void ingresarNuevaRobot();
void ingresarNuevaPieza();
void obtenerRobotEquipo();
void obtenerEstadiscticasVictoriaHumanidad();
void cerrar() throws IOException;


}
