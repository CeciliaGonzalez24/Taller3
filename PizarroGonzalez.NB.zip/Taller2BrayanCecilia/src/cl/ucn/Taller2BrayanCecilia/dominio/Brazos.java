package cl.ucn.Taller2BrayanCecilia.dominio;

public class Brazos extends Pieza {

public Brazos(String nombre, String rareza, String tipo,int ataque) {
		super(nombre, rareza, tipo);
		super.setAtaque(super.getAtaque()+ataque);
		// TODO Auto-generated constructor stub
	}




}
