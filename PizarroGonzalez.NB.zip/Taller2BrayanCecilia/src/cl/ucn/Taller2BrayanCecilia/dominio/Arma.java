package cl.ucn.Taller2BrayanCecilia.dominio;

public class Arma {
private String nombre;
private int dano;
private int velAtq;


public Arma(String nombre,int dano,int velAtq) {
	this.nombre=nombre;
	this.dano=dano;
	this.velAtq=velAtq;
	
}

public String getNombre() {
	return nombre;
}

public void setNombre(String nombre) {
	this.nombre = nombre;
}

public int getDano() {
	return dano;
}

public void setDano(int dano) {
	this.dano = dano;
}

public int getVelAtq() {
	return velAtq;
}

public void setVelAtq(int velAtq) {
	this.velAtq = velAtq;
}
}
