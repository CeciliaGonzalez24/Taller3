package cl.ucn.Taller2BrayanCecilia.dominio;

public class Cabeza extends Pieza{

public Cabeza(String nombre, String rareza, String tipo, int vida, int velocidad) {
	super(nombre, rareza, tipo);
	super.setVelocidad(super.getVelocidad()+velocidad);
	super.setVidabase(super.getVidabase()+vida);
}



}
