package cl.ucn.Taller2BrayanCecilia.dominio;

public class RobotA extends Robots{
private String clase;  
private int escudo;
public RobotA(String nombre,String clase,int escudo) {
	super(nombre);
	this.clase=clase;
	this.escudo=escudo;
}

public int getEscudo() {
	return escudo;
}

public void setEscudo(int escudo) {
	this.escudo = escudo;
}

public String getClase() {
	return clase;
}
public void setClase(String clase) {
	this.clase = clase;
}

@Override
public void calcular() {
	int vida=0;
	int ataque=0;
	int velocidad=0;
	switch (clase) {
	case "SS+": {
		vida+=5000;
		ataque+=400;
	}
	case "S+":{
		vida+=3000;
		ataque+=400;
	}
	case "S":{
		vida+=2000;
		ataque+=300;
	}
	case "A":{
		vida+=1000;
		ataque+=200;
	}
	case "B":{
		vida+=500;
		ataque+=100;
	}
	}
	
	
	switch (this.getTorax().getRareza()){
	case "PP": {
	vida+=3000;
	ataque+=200;
	}
	case "PE":{
		vida+=2000;
		ataque+=100;
	}
	case "PC":{
		vida+=1000;
	}
	
	}
	
	switch (this.getCabeza().getRareza()){
	case "PP": {
		vida+=3000;
		ataque+=200;
	}
	case "PE":{
		vida+=2000;
		ataque+=100;
	}
	case "PC":{
		vida+=1000;
	}

	}

	switch (this.getBrazos().getRareza()){
	case "PP": {
		vida+=3000;
		ataque+=200;
	}
	case "PE":{
		vida+=2000;
		ataque+=100;
	}
	case "PC":{
		vida+=1000;
	}

	}
	
	switch (this.getPiernas().getRareza()){
	case "PP": {
		vida+=3000;
		ataque+=200;
	}
	case "PE":{
		vida+=2000;
		ataque+=100;
	}
	case "PC":{
		vida+=1000;
	}

	}
	
	vida+=this.getTorax().getVidabase()+this.getCabeza().getVidabase();
	ataque+=this.getBrazos().getAtaque()+this.getArma().getDano();
	velocidad+=this.getArma().getVelAtq()+this.getPiernas().getVelocidad();
	
	this.setVelocidad(velocidad);
	this.setAtaque(ataque);
	this.setVida(vida);
		
}

@Override
public String toString() {
	return "RobotA [NOMBRE" + getNombre() + ", CLASE=" + clase + ", ESCUDO=" + getEscudo() + ", VIDA="
			+ getVida() + ", VELOCIDAD=" + getVelocidad() + ", ATAQUE=" + getAtaque() + ", PIERNAS"
			+ getPiernas().getNombre() + ", BRAZOZ=" + getBrazos().getNombre() + ", TORAX=" + getTorax().getNombre() + ", CABEZA="
			+ getCabeza().getNombre();
}
	
	
	
}


