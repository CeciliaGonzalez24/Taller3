package cl.ucn.Taller2BrayanCecilia.dominio;

public class Piernas extends Pieza{

public Piernas(String nombre, String rareza, String tipo, int velociadad) {
		super(nombre, rareza, tipo);
		setVelocidad(velociadad+super.getVelocidad());
		// TODO Auto-generated constructor stub
	}





}
