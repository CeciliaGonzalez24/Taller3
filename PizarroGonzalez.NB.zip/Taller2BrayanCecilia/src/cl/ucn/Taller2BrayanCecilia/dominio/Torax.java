package cl.ucn.Taller2BrayanCecilia.dominio;

public class Torax extends Pieza {
	
	
public Torax(String nombre, String rareza, String tipo, int vida) {
	super(nombre, rareza, tipo);
	super.setVidabase(super.getVidabase()+vida);
}



}
