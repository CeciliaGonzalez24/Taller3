package cl.ucn.Taller2BrayanCecilia.dominio;


public abstract class Robots {

private String nombre;
private Arma arma;
private Piernas piernas;
private Brazos brazos;
private Torax torax;
private Cabeza cabeza;
private int vida;
private int ataque;
private int velocidad;
/**
 * 
 * @param nombre
 */
protected Robots(String nombre) {
	this.nombre = nombre;
	this.piernas = null;
	this.brazos = null;
	this.torax = null;
	this.cabeza = null;
	this.arma=null;
	this.vida=0;
	this.ataque=0;
	this.velocidad=0;
}

public String getNombre() {
	return nombre;
}

public void setNombre(String nombre) {
	this.nombre = nombre;
}

public Arma getArma() {
	return arma;
}

public void setArma(Arma arma) {
	this.arma = arma;
}

public Piernas getPiernas() {
	return piernas;
}

public void setPiernas(Piernas piernas) {
	this.piernas = piernas;
}

public Brazos getBrazos() {
	return brazos;
}

public void setBrazos(Brazos brazos) {
	this.brazos = brazos;
}

public Torax getTorax() {
	return torax;
}

public void setTorax(Torax torax) {
	this.torax = torax;
}

public Cabeza getCabeza() {
	return cabeza;
}

public void setCabeza(Cabeza cabeza) {
	this.cabeza = cabeza;
}

public int getVida() {
	return vida;
}

public void setVida(int vida) {
	this.vida = vida;
}

public int getAtaque() {
	return ataque;
}

public void setAtaque(int ataque) {
	this.ataque = ataque;
}

public int getVelocidad() {
	return velocidad;
}

public void setVelocidad(int velocidad) {
	this.velocidad = velocidad;
}

public abstract void calcular();
}


