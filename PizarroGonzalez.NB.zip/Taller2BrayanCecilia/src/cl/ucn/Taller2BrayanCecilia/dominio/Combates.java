package cl.ucn.Taller2BrayanCecilia.dominio;

import java.util.ArrayList;

public class Combates {
private ArrayList<Robots> lr;
private String ganador;

public Combates() {
	lr = new ArrayList<>();
	this.ganador="";
}

public ArrayList<Robots> getLr() {
	return lr;
}

public void setLr(ArrayList<Robots> lr) {
	this.lr = lr;
}

public String getGanador() {
	return ganador;
}

public void setGanador(String ganador) {
	this.ganador = ganador;
}

}
