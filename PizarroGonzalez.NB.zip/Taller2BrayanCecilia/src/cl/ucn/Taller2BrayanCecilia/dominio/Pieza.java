package cl.ucn.Taller2BrayanCecilia.dominio;

public class Pieza {
private String nombre;
private String rareza;
private String tipo;
private int vidabase;
private int ataque;
private int velocidad;

public Pieza(String nombre,String rareza,String tipo) {
	this.nombre=nombre;
	this.rareza=rareza;
	this.tipo=tipo;
	this.vidabase=2000;
	
}

public String getNombre() {
	return nombre;
}

public void setNombre(String nombre) {
	this.nombre = nombre;
}

public String getRareza() {
	return rareza;
}

public void setRareza(String rareza) {
	this.rareza = rareza;
}

public String getTipo() {
	return tipo;
}

public void setTipo(String tipo) {
	this.tipo = tipo;
}

public int getVidabase() {
	return vidabase;
}

public void setVidabase(int vidabase) {
	this.vidabase = vidabase;
}

public int getAtaque() {
	return ataque;
}

public void setAtaque(int ataque) {
	this.ataque = ataque;
}

public int getVelocidad() {
	return velocidad;
}

public void setVelocidad(int velocidad) {
	this.velocidad = velocidad;
}

}
