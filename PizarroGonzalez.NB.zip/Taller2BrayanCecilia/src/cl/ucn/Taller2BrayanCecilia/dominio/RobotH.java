package cl.ucn.Taller2BrayanCecilia.dominio;

public class RobotH extends Robots {
private String nomPiloto;
private String equipoMan;

public RobotH(String nombre,String nomPiloto,String equipoMan) {
	super(nombre);
	this.nomPiloto=nomPiloto;
	this.equipoMan=equipoMan;
	
}

public String getNomPiloto() {
	return nomPiloto;
}

public void setNomPiloto(String nomPiloto) {
	this.nomPiloto = nomPiloto;
}

public String getEquipoMan() {
	return equipoMan;
}

public void setEquipoMan(String equipoMan) {
	this.equipoMan = equipoMan;
}

@Override
public void calcular() {
	// TODO Auto-generated method stub
	int vida=0;
	int ataque=0;
	int velocidad=0;
	
	switch (getTorax().getRareza()){
	case "PP": {
	vida+=3000;
	ataque+=200;
	}
	case "PE":{
		vida+=2000;
		ataque+=100;
	}
	case "PC":{
		vida+=1000;
	}
	
	}

	switch (getCabeza().getRareza()){
	case "PP": {
		vida+=3000;
		ataque+=200;
	}
	case "PE":{
		vida+=2000;
		ataque+=100;
	}
	case "PC":{
		vida+=1000;
	}

	}

	switch (getBrazos().getRareza()){
	case "PP": {
		vida+=3000;
		ataque+=200;
	}
	case "PE":{
		vida+=2000;
		ataque+=100;
	}
	case "PC":{
		vida+=1000;
	}

	}
	
	switch (getPiernas().getRareza()){
	case "PP": {
		vida+=3000;
		ataque+=200;
	}
	case "PE":{
		vida+=2000;
		ataque+=100;
	}
	case "PC":{
		vida+=1000;
	}

	}
	vida+=getTorax().getVidabase()+getCabeza().getVidabase();
	ataque+=getBrazos().getAtaque()+getArma().getDano();
	velocidad+=getArma().getVelAtq()+getPiernas().getVelocidad();
	
	setVelocidad(velocidad);
	setAtaque(ataque);
	setVida(vida);
}

@Override
public String toString() {
	return "RobotA [NOMBRE" + getNombre() + ", EQUIPO=" + getEquipoMan() + ", PILOTO=" + getNomPiloto() + ", VIDA="
			+ getVida() + ", VELOCIDAD=" + getVelocidad() + ", ATAQUE=" + getAtaque() + ", PIERNAS"
			+ getPiernas().getNombre() + ", BRAZOZ=" + getBrazos().getNombre() + ", TORAX=" + getTorax().getNombre() + ", CABEZA="
			+ getCabeza().getNombre();
}

}
